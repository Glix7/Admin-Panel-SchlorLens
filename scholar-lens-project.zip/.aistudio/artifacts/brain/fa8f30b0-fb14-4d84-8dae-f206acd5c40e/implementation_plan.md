# Implementation Plan: Scholar Lens Production-Grade Admin Platform

## 1. Confirmed Project Purpose & Scope
**Scholar Lens** is a curated intelligence and management platform for funded technical Master's (and Master's-or-PhD) scholarships, fellowships, and bursaries for **Indian applicants** in CS, AI/ML, embedded systems, robotics, cybersecurity, VLSI, and related fields.

The system empowers administrators to curate, audit, validate, import, export, and monitor opportunities while exposing real-time metrics to applicants and matching engines.

---

## 2. Architecture & Tech Stack

```
┌─────────────────────────────────────────────────────────────┐
│                 Client: React 19 + Vite                     │
│  Tailwind CSS v4 · Lucide React · Recharts · TypeScript    │
└──────────────────────────────┬──────────────────────────────┘
                               │ HTTP / httpOnly Cookie
┌──────────────────────────────▼──────────────────────────────┐
│              Server: Node.js + Express (server.ts)          │
│   Vite dev middleware (port 3000) · Cookie-based sessions   │
│   Bcrypt password hashing · RBAC Middleware (Admin/Viewer)  │
│   Zod request validation · RFC 4180 CSV engine              │
└──────────────────────────────┬──────────────────────────────┘
                               │ Atomic Reads/Writes
┌──────────────────────────────▼──────────────────────────────┐
│              Persistent File Database (data/)               │
│   opportunities.json (112 seed + 4 fixtures) · logs.json    │
│   users.json (admin & viewer accounts with bcrypt hashes)   │
└─────────────────────────────────────────────────────────────┘
```

### Technology Selections:
* **Frontend:** React 19, TypeScript (strict), Vite 8, Tailwind CSS v4.
* **Backend:** Express 4 on port 3000 running in `server.ts` with `tsx` and mounting Vite middleware in development.
* **Authentication:** Real backend session authentication using `httpOnly`, `SameSite=Lax`, signed cookies. Passwords hashed server-side using bcrypt.
* **Authorization:** Strict role checking on all write operations (`admin` allowed, `viewer` or anonymous returned `401`/`403`).
* **Persistence:** Atomic JSON file store with mutex-guarded disk synchronization, preserving all mutations and audit logs across server restarts.
* **Data Ingest & Export:** Server-side RFC 4180 compliant CSV parser and streaming exporter with formula injection sanitization (`=`, `+`, `-`, `@`).

---

## 3. Dataset Schema & Seed Data (112 Records + 4 Test Fixtures)

### `Opportunity` Interface (25 fields):
1. `id`: string (`"opp-lt-001"` for long-tail, `"opp-wk-001"` for well-known)
2. `title`: string
3. `provider_name`: string
4. `provider_type`: `'university' | 'foundation' | 'government' | 'corporate'`
5. `host_country`: string (25 distinct countries)
6. `host_institution`: string
7. `degree_level`: `'masters' | 'masters_or_phd'`
8. `funding_type`: `'full' | 'partial' | 'stipend_only' | 'tuition_waiver' | 'travel_grant'`
9. `funding_summary`: string
10. `funding_amount_note`: string
11. `fields_of_study`: `string[]`
12. `eligibility_summary`: string
13. `indian_applicants_eligible`: `boolean`
14. `min_gpa_note`: string
15. `language_requirements`: string
16. `application_deadline`: `string | null` (ISO date)
17. `deadline_note`: string
18. `official_url`: string (flagged as unverified placeholder)
19. `tags`: `string[]`
20. `popularity_tier`: `'long_tail' | 'well_known'`
21. `curated_by`: string
22. `verified_on`: string (ISO date)
23. `is_active`: boolean
24. `created_at`: string (ISO datetime)
25. `updated_at`: string (ISO datetime)

### Known Data Quality Issues & Enforced Audits:
1. **Unverified URLs:** All 112 seed `example.com` URLs flagged with a visual and programmatic "unverified link" badge.
2. **Missing Deadlines:** 11 seed records with `application_deadline = null` categorized as "Rolling / Open Admission".
3. **Dynamic Deadline Status:** Computed dynamically at query time:
   * `open`: Deadline > 30 days away.
   * `closing`: Deadline within 30 days of today.
   * `expired`: Deadline < today.
   * `none`: `application_deadline == null`.
4. **Stale Verification:** Flagged when `verified_on` exceeds 90 days from the current date.
5. **Test Fixtures:** 4 clearly marked fixtures (`test-fixture-001` to `004`) with `indian_applicants_eligible: false` and `is_active: false` to validate negative filter scenarios.

---

## 4. API Specification & Endpoints

| Method | Endpoint | Access | Description |
|---|---|---|---|
| `POST` | `/api/auth/login` | Public | Authenticates credentials, sets `httpOnly` cookie |
| `POST` | `/api/auth/logout` | Authenticated | Clears session cookie and writes audit log |
| `GET` | `/api/auth/session` | Public | Returns active user profile and role or `null` |
| `GET` | `/api/records` | Authenticated | Server-side pagination, search, multi-filter, sorting |
| `GET` | `/api/records/:id` | Authenticated | Retrieves single opportunity by ID |
| `POST` | `/api/records` | Admin only | Validates with Zod, persists record, logs activity |
| `PUT` | `/api/records/:id` | Admin only | Validates, updates timestamps, logs changed fields |
| `DELETE` | `/api/records/:id` | Admin only | Deletes record from database and logs action |
| `POST` | `/api/records/import` | Admin only | Uploads CSV, validates headers and rows, duplicate check |
| `GET` | `/api/records/export` | Authenticated | Streams RFC 4180 CSV with sanitized cells |
| `GET` | `/api/stats` | Authenticated | Real database aggregates for dashboard KPI charts |
| `GET` | `/api/activity` | Authenticated | Returns server-written non-repudiation audit logs |
| `GET` | `/api/data-quality` | Authenticated | Returns summary of missing fields, stale verifications, placeholders |
| `POST` | `/api/admin/reset-seed` | Admin only | Resets repository to default 112 seed records |

---

## 5. UI/UX Design System & Pages

* **Design Palette:** Deep Navy (`#0b2540`), Scholar Green (`#12805c`), Subtle Blue (`#2b6cb0`), Clean Slate surfaces, zero-pill typography.
* **Animated Split-Screen Login (`/login`):**
  * Left: Abstract green-blue pixel artwork canvas with Scholar Lens branding, tagline, and reduced-motion detection.
  * Right: Form with email, password show/hide, remember-me, terms checkbox, and demo login buttons.
* **Navigation & Sidebar:** Collapsible sidebar linking to:
  * Overview Dashboard (`/dashboard`)
  * Opportunities Catalog (`/records`)
  * Batch CSV Ingestion (`/import`)
  * Audit Trail Logs (`/activity`)
  * Data Quality Scanner (`/quality`)
  * B.Tech Viva Defense Pack (`/viva`)
* **Dashboard Widgets:**
  * KPI Metric Cards: Total Records, Created Today, Closing in 30 Days, Deadlines Passed, Rolling/No Deadline, Average Field Completeness %.
  * Temporal Deadlines Trajectory (Recharts AreaChart).
  * Country and Funding Type Breakdown (Recharts Bar & Donut charts).
  * Recent activity feed and quick action strip.

---

## 6. Automated Testing & Verification Suite

1. **Unit Tests:**
   * Computed deadline status (`open`, `closing`, `expired`, `none`).
   * RFC 4180 CSV parser and formula injection prevention (`=`, `+`, `-`, `@`).
   * Field completeness scoring algorithm.
2. **Integration / API Tests:**
   * Server authentication and invalid credential rejections.
   * Role enforcement: verify `401 Unauthorized` for unauthenticated calls and `403 Forbidden` for viewer role attempting writes.
   * CRUD lifecycle, pagination, and multi-parameter filtering.
   * CSV batch ingest error reporting.
3. **Build & Type Checking:**
   * Strict `tsc --noEmit` and Vite production build.

---

## 7. Documentation & B.Tech Capstone Deliverables

* `README.md`: Architecture overview, dataset schema, setup instructions, commands, and security details.
* `docs/ARCHITECTURE.md`: Data flow, auth flow, and authorization matrix.
* `docs/VIVA.md`: 2-minute project pitch, architectural breakdown, and 25 viva voce questions with detailed answers.
* `docs/TEST_REPORT.md`: Comprehensive log of all executed tests and verified functionality.
